#ifndef INSERT_H 
#define INSERT_H 
#include "node.h"
#include <stdio.h>

struct node* insert(struct node* node, int key);

#endif 
