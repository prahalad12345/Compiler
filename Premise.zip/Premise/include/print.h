#ifndef PRINT_H 
#define PRINT_H 
#include "node.h"
#include <stdio.h> 

void inorder(struct node* root);

#endif 